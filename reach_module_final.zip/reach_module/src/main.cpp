#include "module.h"
#include "hooks/reach.cpp"
#include <pthread.h>
#include <unistd.h>

static void* hookThread(void*) {
    LOGI("[*] ReachModule thread started, waiting for MC...");

    // Poll until libminecraftpe.so is in memory
    int retries = 0;
    while (MC::getBase() == 0) {
        if (++retries > 240) {
            LOGE("[-] Timeout waiting for libminecraftpe.so");
            return nullptr;
        }
        usleep(500000); // 500ms
    }

    LOGI("[*] MC base found after %d polls (%.1fs)", retries, retries * 0.5f);
    usleep(2500000); // 2.5s settle time

    initReachHooks();
    return nullptr;
}

// ── JNI entry point (LeviLauncher dlopen path) ──────────
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("[*] ReachModule JNI_OnLoad");
    pthread_t tid;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&tid, &attr, hookThread, nullptr);
    pthread_attr_destroy(&attr);
    return JNI_VERSION_1_6;
}

// ── Constructor fallback (some launchers skip JNI_OnLoad) ─
extern "C" __attribute__((constructor)) void __module_init() {
    static bool ran = false;
    if (ran) return;
    ran = true;
    LOGI("[*] ReachModule constructor init");
    pthread_t tid;
    pthread_create(&tid, nullptr, hookThread, nullptr);
    pthread_detach(tid);
}
