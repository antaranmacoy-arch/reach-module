#include "../module.h"
#include <dobby.h>

// ═══════════════════════════════════════════════════════════
//  REACH MODULE — 100 block reach
//  Hooks: getAttackRange, canAttack, GameMode::attack
//  Strategy: triple-layer — cleaner, harder to patch out
// ═══════════════════════════════════════════════════════════

static constexpr float REACH          = 100.0f;
static constexpr float REACH_SQ       = REACH * REACH;
static constexpr float REACH_PICKUP   = 100.0f; // item pickup range bonus

// ──────────────────────────────────────────────────────────
//  OFFSETS — update these per MC version
//  How to find: Ghidra > search string "attack" > xref
//  OR use patternScan below instead
//
//  These are 1.20.81 arm64 approximate — REPLACE with yours
// ──────────────────────────────────────────────────────────
namespace Offsets {
    constexpr uintptr_t GetAttackRange  = 0x00000000; // Player::getAttackRange
    constexpr uintptr_t CanAttack       = 0x00000000; // Actor::canAttack
    constexpr uintptr_t GameModeAttack  = 0x00000000; // GameMode::attack
}

// ──────────────────────────────────────────────────────────
//  ARM64 BYTE PATTERNS (fallback when offsets unknown)
//  These are approximate — tune per version in Ghidra
// ──────────────────────────────────────────────────────────
// getAttackRange typical prologue (ARM64):
//   STP  X29, X30, [SP, #-0x10]!
//   MOV  X29, SP
//   LDR  S0, [X0, #offset]  ; loads float reach
static const uint8_t PAT_ATTACK_RANGE[] = {
    0xFD, 0x7B, 0xBF, 0xA9,  // STP X29,X30,[SP,#-0x10]!
    0xFD, 0x03, 0x00, 0x91,  // MOV X29, SP
};
static const char MSK_ATTACK_RANGE[] = "xxxxxxxx";

// ──────────────────────────────────────────────────────────
//  HOOK 1: Player::getAttackRange
//  float getAttackRange(bool creative)
// ──────────────────────────────────────────────────────────
using FnGetAttackRange = float(*)(void* player, bool creative);
FnGetAttackRange orig_GetAttackRange = nullptr;

float hook_GetAttackRange(void* player, bool creative) {
    return REACH;
}

// ──────────────────────────────────────────────────────────
//  HOOK 2: Actor::canAttack
//  bool canAttack(Actor* target, bool creative)
//  We skip the distance check — always true
// ──────────────────────────────────────────────────────────
using FnCanAttack = bool(*)(void* self, void* target, bool creative);
FnCanAttack orig_CanAttack = nullptr;

bool hook_CanAttack(void* self, void* target, bool creative) {
    return true; // bypass all distance validation
}

// ──────────────────────────────────────────────────────────
//  HOOK 3: GameMode::attack
//  void attack(Actor* attacker, Actor* victim)
//  Patches the internal sqDist >= reachSq branch
//  by just passing through after hooks 1+2 already expanded it
// ──────────────────────────────────────────────────────────
using FnGameModeAttack = void(*)(void* gm, void* attacker, void* victim);
FnGameModeAttack orig_GameModeAttack = nullptr;

void hook_GameModeAttack(void* gm, void* attacker, void* victim) {
    orig_GameModeAttack(gm, attacker, victim);
}

// ──────────────────────────────────────────────────────────
//  RESOLVE — offset or pattern scan
// ──────────────────────────────────────────────────────────
static uintptr_t resolveAddr(uintptr_t manualOffset,
                              const uint8_t* pattern,
                              const char* mask,
                              size_t patLen,
                              const char* name) {
    uintptr_t base = MC::getBase();
    if (!base) return 0;

    // prefer manual offset if set
    if (manualOffset != 0) {
        LOGI("[+] %s via manual offset: 0x%lx", name, base + manualOffset);
        return base + manualOffset;
    }

    // fallback pattern scan
    uintptr_t found = patternScan(pattern, mask, patLen);
    if (found) {
        LOGI("[+] %s via pattern: 0x%lx", name, found);
    } else {
        LOGE("[-] %s not found", name);
    }
    return found;
}

// ──────────────────────────────────────────────────────────
//  INIT — install all hooks
// ──────────────────────────────────────────────────────────
void initReachHooks() {
    uintptr_t base = MC::getBase();
    if (!base) {
        LOGE("[-] libminecraftpe.so base not found");
        return;
    }
    LOGI("[*] libminecraftpe base: 0x%lx", base);

    // ── Hook 1: getAttackRange ──
    uintptr_t addrRange = resolveAddr(
        Offsets::GetAttackRange,
        PAT_ATTACK_RANGE, MSK_ATTACK_RANGE, sizeof(PAT_ATTACK_RANGE),
        "getAttackRange"
    );
    if (addrRange) {
        DobbyHook((void*)addrRange,
                  (void*)hook_GetAttackRange,
                  (void**)&orig_GetAttackRange);
        LOGI("[+] Hook1 installed: getAttackRange → %.1f", REACH);
    }

    // ── Hook 2: canAttack ──
    uintptr_t addrCan = resolveAddr(
        Offsets::CanAttack,
        PAT_ATTACK_RANGE, MSK_ATTACK_RANGE, sizeof(PAT_ATTACK_RANGE), // replace pattern
        "canAttack"
    );
    if (addrCan) {
        DobbyHook((void*)addrCan,
                  (void*)hook_CanAttack,
                  (void**)&orig_CanAttack);
        LOGI("[+] Hook2 installed: canAttack → always true");
    }

    // ── Hook 3: GameMode::attack (optional) ──
    if (Offsets::GameModeAttack != 0) {
        uintptr_t addrAtk = base + Offsets::GameModeAttack;
        DobbyHook((void*)addrAtk,
                  (void*)hook_GameModeAttack,
                  (void**)&orig_GameModeAttack);
        LOGI("[+] Hook3 installed: GameMode::attack passthrough");
    }

    LOGI("[*] ReachModule active — %.0f block reach", REACH);
}
